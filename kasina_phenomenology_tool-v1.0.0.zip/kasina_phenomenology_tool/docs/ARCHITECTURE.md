# Kasina Phenomenology Tool: architecture (v1.0.0)

## Purpose

After practice, practitioners use the tool to rebuild what they saw during fire kasina meditation: the afterimage / nimitta, its glow, its (in)stability, and peripheral phenomena such as rings of orbiting dots. Because the percept changes over a sit, a report holds **three stages**: beginning (most vivid), midway and tail end. The output is a **parameter set**, not just a picture. That makes reports comparable across people and sessions and allows them to be rated, clustered and related to EEG.

## Design principles

1. **Scene = data.** Everything on screen is a pure function of `(scene JSON, time)`. A saved report is a complete, reproducible description that can be versioned, compared and analysed.
2. **Bounded, continuous parameters.** Every parameter has a defined range and unit. This supports rating grids, interpolation, optimisation and statistics.
3. **Stable identities across stages.** When a stage is copied, layer ids are kept, so "the disc" in stage 1 and "the disc" in stage 3 are the same object. This enables morphing and quantitative change scores (e.g. disc radius at the beginning vs. the tail end).
4. **Layer composition.** Percepts are built from a small set of primitives (disc, aura, dot rings), stacked back to front. New phenomena = new layer types.
5. **Schema-driven UI.** Controls are generated from a per-type schema (`ui.js` → `SCHEMAS`). Adding a parameter is one schema line plus its use in the shader.
6. **No build step, no dependencies.** Plain JavaScript and WebGL2. It runs by double-clicking `app/index.html` and works offline. It can be hosted on GitHub Pages unchanged.

## Repository layout

```
app/
  index.html            page shell; loads scripts in dependency order
  style.css             panel styling
  src/
    color.js            sRGB ↔ OKLab / OKLCH conversions, gamut mapping, perceptual mixing
    scene.js            data model: layer factories, scenes, reports (3 stages), normalisation
    presets.js          scene presets + three-stage example report
    modulation.js       temporal stability: steady / flicker / fade cycle / drift / follow parent
    interpolate.js      stage-to-stage morphing and sequence timing
    renderer.js         WebGL2: one full-screen pass per layer, type-specific fragment shaders
    ui.js               panel: report and stages, layer list, schema-generated parameter controls
    main.js             app state, clock, render loop, sequence playback, autosave, files, shortcuts
docs/
  ARCHITECTURE.md       this file
  screenshots/
examples/
  example_three_stage_report.json
```

Data flow:

```
              edits            ┌───────────────────────────┐
  ui.js  ───────────────────▶  │ report                    │ ◀── import JSON / presets
                               │  meta                     │ ──▶ autosave / export JSON
                               │  stages[0..2].scene  ◀────┼──── "copy previous stage"
                               └─────────────┬─────────────┘
                                             │ current stage, or
                                             │ interpolate.js (sequence 1 → 2 → 3)
                 clock t                     ▼
  modulation.js (opacity gain) ──▶ renderer.js (WebGL2) ──▶ canvas ──▶ PNG
```

## Data model (schemaVersion 2)

Scene coordinates: the screen centre is (0, 0) and **1 unit = half the shorter screen side**. +y is up. Angles are in degrees, and colours are sRGB hex.

```jsonc
{
  "schemaVersion": 2,
  "meta":   { "participant": "", "session": "", "date": "2026-11-19", "notes": "" },
  "stages": [
    { "key": "beginning", "label": "Beginning (most vivid)", "notes": "", "scene": SCENE },
    { "key": "midway",    "label": "Midway",                 "notes": "", "scene": SCENE },
    { "key": "tail",      "label": "Tail end",               "notes": "", "scene": SCENE }
  ],
  "sequence": { "hold": 4, "morph": 3 }        // playback timing in seconds
}

SCENE = {
  "background": { "level": 0.0, "tint": "#ffffff" },  // level 0 = black … 0.6 = grey
  "layers": [ LAYER, … ]                              // drawn first → last (last = front)
}
```

### Layer types

| Type | Models | Parameters |
|---|---|---|
| **disc** | The kasina / nimitta. Round or oval, can be layered | `x, y, rx, ry, rot, softness, colorInner, colorOuter, gradient, opacity, blend` |
| **aura** | Cloudy glow around a disc | `attachTo, size` (× radius), `color, opacity, density, falloff, turbulence` (cloudiness), `noiseScale` (grain), `drift` (motion), `blend`. Free position (`x, y, rx, ry, rot`) if not attached |
| **dotRing** | Dots orbiting a disc, one or several rings, optionally spiralling | `attachTo, radius` (innermost), `ellipticity, rot` (tilt), `speed` (rev/s), `wobble, rings, ringSpacing, count` (inner ring), `countStep` (extra per ring), `direction` (same/alternate), `speedFalloff` (outer slower), `twist` (°/unit, spiral arms), `radialSpeed` (units/s, + outward / − inward), `dotSize, softness, color, opacity, blend` |

Every layer also has `id`, `name`, `visible` and `mod` (stability).

**Spiral flow:** with `radialSpeed ≠ 0`, each ring's radius advances over time and wraps around within the band `[radius, radius + rings × ringSpacing]`. It fades in and out at the band edges, so dots stream continuously inward or outward while orbiting. Each dot therefore traces a spiral. `twist` adds a radius-dependent angular offset, which bends rings into spiral arms.

### Stability (`mod`)

Each layer has one modulator. It returns a gain in [0, 1] that multiplies opacity.

| Type | Behaviour | Parameters |
|---|---|---|
| steady | always on | n/a |
| flicker | periodic | `freq` (Hz), `waveform` (square/sine/triangle), `duty`, `depth`, `phase` |
| fadeCycle | visible, then fades out, stays gone, then returns | `holdOn, fadeOut, holdOff, fadeIn` (s), `depth`, `phase` |
| drift | irregular, smooth random waxing and waning | `rate, seed, depth` |
| parent | copies the attached disc's modulation | n/a |

## Colour: why OKLCH

Hex / RGB describes how much red, green and blue light the screen emits. That is convenient for the screen but not how colour is perceived. For example, moving an RGB slider by the same amount can produce a large visible change in one region and almost none in another, and changing "brightness" in RGB also shifts the perceived hue and saturation.

**OKLCH** (Ottosson, 2020) is a perceptual colour space with three independent axes:

- **L, lightness** (0 = black, 1 = white)
- **C, chroma** (0 = grey, higher = more colourful)
- **H, hue** (angle in degrees: ≈30 red, ≈70 orange, ≈100 yellow, ≈145 green, ≈265 blue, ≈330 magenta)

Equal steps look roughly equally large, and you can adjust one quality ("a bit less saturated", "slightly more towards red") without disturbing the others. This matches how practitioners describe colour and gives analysable dimensions: lightness, chroma and hue of the nimitta can be compared across stages and people. Some L/C/H combinations cannot be shown on an sRGB screen. In that case the tool keeps lightness and hue, reduces chroma, and says so. Colours are still stored as hex for simplicity. Stage morphing blends colours in OKLab, so transitions do not pass through muddy intermediate colours.

## Rendering

- WebGL2, one full-screen triangle per layer, with premultiplied-alpha compositing (`ONE, ONE_MINUS_SRC_ALPHA`, or `ONE, ONE` for additive light).
- Disc: elliptical distance field, smoothstep edge, radial colour gradient.
- Aura: elliptical falloff × domain-warped fBm noise, animated over time.
- Dot rings: analytic. For each ring (≤ 24), the shader finds the nearest dot by angle, so cost does not depend on dot count.

## Morphing between stages

`interpolateScenes(A, B, m)`: layers present in both stages (same id) are interpolated, with numbers blended linearly, colours in OKLab, and discrete settings switching at m = 0.5. Layers present in only one stage fade out or in. Sequence playback: hold stage 1 → morph → hold stage 2 → morph → hold stage 3 (cosine easing). It plays once.

## Timing and safety

- The tool is built for **replication after practice**. Flicker can only change on frame boundaries, so frequencies above half the refresh rate alias, and the status bar warns about this. Browser timing is not suitable for stimulus-locked EEG analysis.
- **Photosensitive epilepsy:** flicker at roughly 3–30 Hz can trigger seizures. The UI warns when flicker is selected. Participant-facing studies need screening and consent.

## Roadmap

- Multiple modulators per layer with targets (size pulsing, colour cycling, position jitter)
- More primitives: flame/candle shape, halo/rim ring, radial rays, complementary-colour afterimage transitions, vortex texture, fragmentation/sparkles
- Optional visual-angle units (screen size + viewing distance)
- Video export (WebM)
- Guided report flow with a short questionnaire; rating mode / stimulus grid for comparing replications across people
- Analysis helpers: flatten reports to long-format CSV (one row per stage × layer × parameter)
