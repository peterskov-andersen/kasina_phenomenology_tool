# Changelog

## [1.0.0] – 2026-11-19

First public release.

### Added
- Three-stage reports: beginning (most vivid), midway and tail end, with participant ID, session, date and free-text notes per stage
- "Copy previous stage here" so the same objects can be followed and adjusted across stages
- Sequence playback (1 → 2 → 3) with parameter morphing: matching layers are interpolated, and colours are blended in OKLab
- Dot rings: up to 24 concentric rings, extra dots per ring, counter-rotating neighbours, slower outer rings, spiral twist and inward/outward spiral flow
- Perceptual OKLCH colour sliders (lightness, chroma, hue) with screen-gamut mapping
- New presets: concentric dot rings, spiralling dot vortex, and a three-stage example report
- Report-level JSON export/import (schema version 2); v0.1 scene files are still accepted
- README with citation information, `CITATION.cff` and MIT license

## [0.1.0] – 2026-11-19

Prototype: background, layered discs, aura, single dot ring, stability modulation (steady, flicker, fade cycle, drift, follow parent), presets, JSON scene export/import, PNG snapshot.
