# Kasina Phenomenology Tool

**Version 1.0.0** · Peter Moltke Skov-Andersen · MIT License

A browser-based tool for replicating the visual phenomenology of **fire kasina** meditation. After a sit, practitioners rebuild what they saw: the afterimage / nimitta disc, its glow, its (in)stability, and peripheral phenomena such as rings of orbiting dots. They do this at three stages of the experience: **beginning (most vivid)**, **midway** and **tail end**. Each report is saved as a reproducible parameter set (JSON). That makes first-person reports comparable across practitioners and sessions, and they can be analysed alongside physiological data such as EEG.

![Three stages of an example report](docs/screenshots/three_stages.png)

## Quick start

1. Download **`kasina_phenomenology_tool.html`** and open it in Chrome, Edge or Firefox (double-click). It is a single self-contained file: no installation, server or internet connection needed. WebGL2 is required.
   - Developers: the same tool is in `app/` as separate source files (`app/index.html` + `app/src/`). If you open `app/index.html`, the `src/` folder and `style.css` must be next to it, so extract the zip first rather than opening it from inside the zip. After editing `app/`, regenerate the single file with `python tools/build_standalone.py`.
2. Choose stage 1 and build the scene. Copy it to stage 2 ("Copy previous stage here") and adjust it, then do the same for stage 3.
3. Press **Export report (JSON)** to save.

| Key | Action |
|---|---|
| H | Hide / show the panel and cursor for clean viewing |
| F | Fullscreen |
| Space | Pause / resume |
| 1 / 2 / 3 | Switch stage |
| S | Play the sequence 1 → 2 → 3 with smooth morphing |

## Features

**Elements (layers)**
- **Discs**: round or oval, with rotation, edge softness, centre → edge colour gradient and opacity. Stack as many as needed (e.g. a white core inside an orange oval).
- **Aura**: a cloudy glow attached to a disc, with its own colour, opacity, density, size, falloff, cloudiness, grain and motion.
- **Dot rings**: dots orbiting a disc. Use one ring or up to 24 concentric rings, with extra dots per ring, counter-rotating neighbours, slower outer rings, **spiral twist** and **spiral flow** (dots streaming inward or outward while orbiting).

**Stability (per element)**: steady · flicker (Hz, waveform, duty cycle) · fade out and return (hold/fade timings) · irregular drift · follow the parent disc.

**Colour**: picker, hex code, kasina-colour swatches, and **perceptual OKLCH sliders** (lightness, chroma, hue).

**Background**: from black to grey, with an optional tint.

**Three-stage reports**: participant ID, session, date, free-text notes per stage, and sequence playback that morphs smoothly from stage to stage.

**Files**: JSON export/import (v0.1 single-scene files are also accepted), PNG snapshot, and automatic saving in the browser.

## Report format

```jsonc
{
  "app": "kasina-phenomenology-tool", "appVersion": "1.0.0", "schemaVersion": 2,
  "meta": { "participant": "P01", "session": "sit 3", "date": "2026-11-19", "notes": "" },
  "stages": [
    { "key": "beginning", "label": "Beginning (most vivid)", "notes": "…", "scene": { "background": {…}, "layers": [ … ] } },
    { "key": "midway",    … },
    { "key": "tail",      … }
  ],
  "sequence": { "hold": 4, "morph": 3 }
}
```

Layers keep the same `id` across stages when copied, so the same object can be followed (and compared quantitatively) from beginning to tail end. See [`examples/example_three_stage_report.json`](examples/example_three_stage_report.json) and the full data model in [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Safety note

Flickering light at roughly **3–30 Hz can trigger seizures** in people with photosensitive epilepsy. The tool warns when flicker is selected. Screen participants before letting them use flicker settings.

## Limitations

- The tool is designed for **replication after practice**, not as a precisely timed stimulus. Flicker is limited by the display refresh rate (frequencies above half the refresh rate alias), and browser timing is not suitable for stimulus-locked EEG analysis.
- Sizes are in screen-relative units (1 unit = half the shorter screen side), not degrees of visual angle.
- Colours are shown in the sRGB gamut of the screen. Very saturated perceived colours may not be reproducible.

## How to cite

If you use this tool in research, please cite it:

**APA**

> Skov-Andersen, P. M. (2026). *Kasina Phenomenology Tool* (Version 1.0.0) [Computer software]. https://github.com/peterskov-andersen/kasina_phenomenology_tool

**BibTeX**

```bibtex
@software{skovandersen_2026_kasina,
  author  = {Skov-Andersen, Peter Moltke},
  title   = {Kasina Phenomenology Tool},
  version = {1.0.0},
  year    = {2026},
  url     = {https://github.com/peterskov-andersen/kasina_phenomenology_tool},
  note    = {Browser-based tool for replicating fire kasina visual phenomenology}
}
```

GitHub also reads [`CITATION.cff`](CITATION.cff) and shows a "Cite this repository" button. To get a DOI, connect the repository to [Zenodo](https://zenodo.org) and publish a release.

## Acknowledgements

Inspired by the "parametrised phenomenology" approach of the Qualia Research Institute's tools (Oscilleditor, Tracer Replication Tool, Stimulus Grid). This is an independent implementation and contains no QRI code.

## License

[MIT](LICENSE) © 2026 Peter Moltke Skov-Andersen
