'use strict';
// WebGL2 renderer. Each layer is drawn as one full-screen pass with a
// type-specific fragment shader, composited back-to-front with premultiplied
// alpha. Adding a new layer type = add a shader + a uniform setter below.
(function (KT) {
  const VS = `#version 300 es
void main() {
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}`;

  const HEADER = `#version 300 es
precision highp float;
uniform vec2 uRes;
uniform float uAlpha;
uniform float uTime;
out vec4 outColor;
// pixel -> scene units (centre = 0, 1 unit = half the shorter side, +y up)
vec2 toUnits(vec2 fc) { return (fc - 0.5 * uRes) / (0.5 * min(uRes.x, uRes.y)); }
// rotate p by -a (into the object's own frame)
vec2 unrotate(vec2 p, float a) { float c = cos(a), s = sin(a); return vec2(c * p.x + s * p.y, -s * p.x + c * p.y); }
`;

  const FS = {
    disc: HEADER + `
uniform vec2 uCenter, uRadii;
uniform float uRot, uSoft, uGrad;
uniform vec3 uInner, uOuter;
void main() {
  vec2 p = unrotate(toUnits(gl_FragCoord.xy) - uCenter, uRot);
  float d = length(p / uRadii);                      // 0 = centre, 1 = edge
  float a = 1.0 - smoothstep(1.0 - uSoft, 1.0 + uSoft, d);
  vec3 col = mix(uInner, uOuter, pow(clamp(d, 0.0, 1.0), uGrad));
  a *= uAlpha;
  outColor = vec4(col * a, a);
}`,

    aura: HEADER + `
uniform vec2 uCenter, uRadii;
uniform float uRot, uSize, uDensity, uFalloff, uNoiseScale, uTurb, uDrift;
uniform vec3 uColor;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p), u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
  float v = 0.0, amp = 0.5;
  for (int i = 0; i < 5; i++) { v += amp * noise(p); p = p * 2.03 + 17.0; amp *= 0.5; }
  return v;
}
void main() {
  vec2 p = unrotate(toUnits(gl_FragCoord.xy) - uCenter, uRot);
  float d = length(p / (uRadii * uSize));            // 0 = centre, 1 = outer edge of aura
  float base = pow(clamp(1.0 - d, 0.0, 1.0), uFalloff);
  vec2 q = p * uNoiseScale;
  float t = uTime * uDrift;
  vec2 warp = vec2(fbm(q + vec2(t, 0.0)), fbm(q + vec2(5.2, -t)));   // domain warp -> billowing clouds
  float n = fbm(q + 2.0 * warp);
  float cloud = mix(1.0, smoothstep(0.25, 0.75, n), uTurb);
  float a = clamp(base * cloud * uDensity, 0.0, 1.0) * uAlpha;
  outColor = vec4(uColor * a, a);
}`,

    dotRing: HEADER + `
uniform vec2 uCenter;
uniform float uRadius, uEll, uRot, uCount, uDotSize, uSoft, uSpeed, uWobble;
uniform float uRings, uSpacing, uCountStep, uAlternate, uFalloff, uTwist, uRadial;
uniform vec3 uColor;
const float TAU = 6.28318530718;
const int MAX_RINGS = 24;
void main() {
  vec2 p = unrotate(toUnits(gl_FragCoord.xy) - uCenter, uRot);
  float theta = atan(p.y / uEll, p.x);
  float span = max(uRings * uSpacing, 1e-4);           // radial extent covered by all rings
  float a = 0.0;
  for (int i = 0; i < MAX_RINGS; i++) {
    float fi = float(i);
    if (fi >= uRings) break;
    float baseR = uRadius + fi * uSpacing;
    float r = baseR;
    float edge = 1.0;
    if (uRadial != 0.0) {                               // spiral flow: rings stream out/in and wrap
      float u = mod(fi * uSpacing + uRadial * uTime, span);
      r = uRadius + u;
      float f = 0.2 * span;
      edge = smoothstep(0.0, f, u) * smoothstep(0.0, f, span - u);
    }
    float count = max(1.0, floor(uCount + fi * uCountStep + 0.5));
    float stepA = TAU / count;
    float dir = (uAlternate > 0.5 && mod(fi, 2.0) > 0.5) ? -1.0 : 1.0;
    float spd = uSpeed * dir * pow(uRadius / baseR, uFalloff);
    float ang0 = TAU * spd * uTime + uTwist * r;        // twist bends rings into spiral arms
    float k0 = floor((theta - ang0) / stepA + 0.5);
    for (int j = -1; j <= 1; j++) {                     // nearest dot on this ring and its neighbours
      float k = k0 + float(j);
      float ang = ang0 + k * stepA;
      float idx = mod(k, count) + fi * 7.0;
      float rr = r * (1.0 + uWobble * sin(uTime * 1.7 + idx * 2.399));
      vec2 dotPos = vec2(cos(ang), uEll * sin(ang)) * rr;
      float dist = length(p - dotPos);
      a = max(a, edge * (1.0 - smoothstep(uDotSize * (1.0 - uSoft), uDotSize, dist)));
    }
  }
  a *= uAlpha;
  outColor = vec4(uColor * a, a);
}`,
  };

  const hexToRgb = (hex) => KT.color.hexToRgb(hex);
  const DEG = Math.PI / 180;

  class Renderer {
    constructor(canvas) {
      this.canvas = canvas;
      const gl = canvas.getContext('webgl2', { alpha: false, antialias: false, preserveDrawingBuffer: true });
      if (!gl) throw new Error('WebGL2 is not available in this browser.');
      this.gl = gl;
      this.vao = gl.createVertexArray();
      this.programs = {};
      for (const type of Object.keys(FS)) this.programs[type] = this._program(FS[type]);
    }

    _program(fsSource) {
      const gl = this.gl;
      const compile = (kind, src) => {
        const s = gl.createShader(kind);
        gl.shaderSource(s, src); gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
        return s;
      };
      const prog = gl.createProgram();
      gl.attachShader(prog, compile(gl.VERTEX_SHADER, VS));
      gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, fsSource));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
      const locs = {};
      return { prog, loc: (name) => (name in locs ? locs[name] : (locs[name] = gl.getUniformLocation(prog, name))) };
    }

    resize() {
      const dpr = window.devicePixelRatio || 1;
      const w = Math.max(1, Math.floor(this.canvas.clientWidth * dpr));
      const h = Math.max(1, Math.floor(this.canvas.clientHeight * dpr));
      if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
    }

    render(scene, t) {
      const gl = this.gl;
      this.resize();
      gl.viewport(0, 0, this.canvas.width, this.canvas.height);
      const bg = hexToRgb(scene.background.tint).map((c) => c * scene.background.level);
      gl.clearColor(bg[0], bg[1], bg[2], 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.enable(gl.BLEND);
      gl.bindVertexArray(this.vao);

      for (const layer of scene.layers) {
        if (!layer.visible) continue;
        const alpha = layer.opacity * KT.layerGain(scene, layer, t);
        if (alpha <= 0.001) continue;
        const P = this.programs[layer.type];
        if (!P) continue;
        gl.useProgram(P.prog);
        gl.uniform2f(P.loc('uRes'), this.canvas.width, this.canvas.height);
        gl.uniform1f(P.loc('uAlpha'), alpha);
        gl.uniform1f(P.loc('uTime'), t);
        this['_set_' + layer.type](P, scene, layer, t);
        if (layer.blend === 'additive') gl.blendFunc(gl.ONE, gl.ONE);
        else gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      }
    }

    _set_disc(P, scene, l) {
      const gl = this.gl;
      gl.uniform2f(P.loc('uCenter'), l.x, l.y);
      gl.uniform2f(P.loc('uRadii'), Math.max(l.rx, 1e-4), Math.max(l.ry, 1e-4));
      gl.uniform1f(P.loc('uRot'), l.rot * DEG);
      gl.uniform1f(P.loc('uSoft'), Math.max(l.softness, 1e-3));
      gl.uniform1f(P.loc('uGrad'), l.gradient);
      gl.uniform3fv(P.loc('uInner'), hexToRgb(l.colorInner));
      gl.uniform3fv(P.loc('uOuter'), hexToRgb(l.colorOuter));
    }

    _set_aura(P, scene, l) {
      const gl = this.gl, g = KT.resolveGeometry(scene, l);
      gl.uniform2f(P.loc('uCenter'), g.x, g.y);
      gl.uniform2f(P.loc('uRadii'), Math.max(g.rx, 1e-4), Math.max(g.ry, 1e-4));
      gl.uniform1f(P.loc('uRot'), g.rot * DEG);
      gl.uniform1f(P.loc('uSize'), l.size);
      gl.uniform1f(P.loc('uDensity'), l.density);
      gl.uniform1f(P.loc('uFalloff'), l.falloff);
      gl.uniform1f(P.loc('uNoiseScale'), l.noiseScale);
      gl.uniform1f(P.loc('uTurb'), l.turbulence);
      gl.uniform1f(P.loc('uDrift'), l.drift);
      gl.uniform3fv(P.loc('uColor'), hexToRgb(l.color));
    }

    _set_dotRing(P, scene, l, t) {
      const gl = this.gl, g = KT.resolveGeometry(scene, l);
      gl.uniform2f(P.loc('uCenter'), g.x, g.y);
      gl.uniform1f(P.loc('uRadius'), Math.max(l.radius, 1e-3));
      gl.uniform1f(P.loc('uEll'), Math.max(l.ellipticity, 0.02));
      gl.uniform1f(P.loc('uRot'), l.rot * DEG);
      gl.uniform1f(P.loc('uCount'), Math.max(1, Math.round(l.count)));
      gl.uniform1f(P.loc('uDotSize'), Math.max(l.dotSize, 1e-4));
      gl.uniform1f(P.loc('uSoft'), Math.min(Math.max(l.softness, 0.02), 1));
      gl.uniform1f(P.loc('uSpeed'), l.speed);
      gl.uniform1f(P.loc('uWobble'), l.wobble);
      gl.uniform1f(P.loc('uRings'), Math.min(24, Math.max(1, Math.round(l.rings))));
      gl.uniform1f(P.loc('uSpacing'), Math.max(l.ringSpacing, 1e-3));
      gl.uniform1f(P.loc('uCountStep'), l.countStep);
      gl.uniform1f(P.loc('uAlternate'), l.direction === 'alternate' ? 1 : 0);
      gl.uniform1f(P.loc('uFalloff'), l.speedFalloff);
      gl.uniform1f(P.loc('uTwist'), l.twist * DEG);
      gl.uniform1f(P.loc('uRadial'), l.radialSpeed);
      gl.uniform3fv(P.loc('uColor'), hexToRgb(l.color));
    }
  }

  KT.Renderer = Renderer;
})(window.KT);
