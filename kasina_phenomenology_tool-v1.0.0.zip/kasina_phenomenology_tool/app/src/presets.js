'use strict';
// Starting points. Scene presets load into the current stage; the example
// report fills all three stages.
(function (KT) {
  const scene = KT.createScene;

  KT.PRESETS = {
    'Fire kasina afterimage': () => {
      const disc = KT.createLayer('disc', { name: 'Nimitta disc' });
      const aura = KT.createLayer('aura', { name: 'Glow', attachTo: disc.id });
      const ring = KT.createLayer('dotRing', { name: 'Orbiting dots', attachTo: disc.id, radius: 0.55 });
      return scene([aura, disc, ring]);
    },
    'Plain white disc': () => scene([
      KT.createLayer('disc', { name: 'White disc', colorInner: '#ffffff', colorOuter: '#ffffff', softness: 0.01 }),
    ]),
    'Layered oval discs': () => {
      const outer = KT.createLayer('disc', { name: 'Outer oval', rx: 0.42, ry: 0.32, colorInner: '#ff7a1a', colorOuter: '#c2185b', opacity: 0.8 });
      const inner = KT.createLayer('disc', { name: 'Inner core', rx: 0.18, ry: 0.15, colorInner: '#ffffff', colorOuter: '#ffd27a', softness: 0.15 });
      return scene([outer, inner], { level: 0.04, tint: '#ffffff' });
    },
    'Concentric dot rings': () => {
      const disc = KT.createLayer('disc', { name: 'Disc', rx: 0.22, ry: 0.22 });
      const rings = KT.createLayer('dotRing', { name: 'Counter-rotating rings', attachTo: disc.id, radius: 0.36, rings: 4, ringSpacing: 0.13, count: 10, countStep: 5, direction: 'alternate', speed: 0.06, speedFalloff: 0.5, color: '#ffe9b0' });
      return scene([disc, rings]);
    },
    'Spiralling dot vortex': () => {
      const disc = KT.createLayer('disc', { name: 'Disc', rx: 0.2, ry: 0.2, colorInner: '#ffffff', colorOuter: '#ffd27a' });
      const aura = KT.createLayer('aura', { name: 'Glow', attachTo: disc.id, size: 2.2, opacity: 0.5 });
      const spiral = KT.createLayer('dotRing', { name: 'Inward spiral', attachTo: disc.id, radius: 0.26, rings: 8, ringSpacing: 0.09, count: 9, countStep: 2, speed: 0.12, speedFalloff: 1, twist: 120, radialSpeed: -0.05, dotSize: 0.01, color: '#ffffff' });
      return scene([aura, disc, spiral]);
    },
    'Flicker 10 Hz': () => scene([
      KT.createLayer('disc', { name: 'Flickering disc', mod: { type: 'flicker', freq: 10, waveform: 'square', duty: 0.5, depth: 1 } }),
    ]),
    'Fading and returning': () => {
      const disc = KT.createLayer('disc', { name: 'Fading disc', mod: { type: 'fadeCycle', holdOn: 3, fadeOut: 2, holdOff: 1.5, fadeIn: 2 } });
      const aura = KT.createLayer('aura', { name: 'Glow (follows disc)', attachTo: disc.id, mod: { type: 'parent' } });
      return scene([aura, disc]);
    },
    'Unstable, drifting nimitta': () => {
      const disc = KT.createLayer('disc', { name: 'Unstable disc', colorInner: '#ffe9b0', colorOuter: '#ff8c3a', mod: { type: 'drift', rate: 0.6, depth: 0.8 } });
      const aura = KT.createLayer('aura', { name: 'Cloud', attachTo: disc.id, size: 2.4, turbulence: 0.9, drift: 0.15, mod: { type: 'drift', rate: 0.3, depth: 0.6 } });
      return scene([aura, disc]);
    },
  };

  KT.DEFAULT_PRESET = 'Fire kasina afterimage';

  // Example report: the same three objects evolve from a vivid white-gold disc
  // to a smaller, unstable orange one and finally a dim, fading red-violet one.
  KT.exampleReport = function () {
    const disc = KT.createLayer('disc', { name: 'Nimitta disc', rx: 0.34, ry: 0.34, colorInner: '#ffffff', colorOuter: '#ffe08a', softness: 0.02 });
    const aura = KT.createLayer('aura', { name: 'Glow', attachTo: disc.id, size: 2.2, color: '#ffb347', density: 1.6, opacity: 0.8 });
    const ring = KT.createLayer('dotRing', { name: 'Orbiting dots', attachTo: disc.id, radius: 0.5, rings: 3, ringSpacing: 0.1, count: 14, countStep: 4, speed: 0.1, direction: 'alternate' });
    const report = KT.createReport(scene([aura, disc, ring]));
    const edit = (st, id, changes) => {
      const l = KT.findLayer(report.stages[st].scene, id);
      const { mod, ...rest } = changes;
      Object.assign(l, rest); if (mod) Object.assign(l.mod, mod);
    };
    edit(1, disc.id, { rx: 0.27, ry: 0.25, colorInner: '#ffd27a', colorOuter: '#ff7a1a', mod: { type: 'drift', rate: 0.4, depth: 0.4 } });
    edit(1, aura.id, { color: '#ff7a1a', density: 1.1, turbulence: 0.85 });
    edit(1, ring.id, { opacity: 0.6, speed: 0.06, radialSpeed: -0.03, twist: 60 });
    edit(2, disc.id, { rx: 0.18, ry: 0.15, rot: 20, colorInner: '#ff7a1a', colorOuter: '#c2185b', opacity: 0.75, softness: 0.2, mod: { type: 'fadeCycle', holdOn: 1.5, fadeOut: 2, holdOff: 1.5, fadeIn: 2 } });
    edit(2, aura.id, { color: '#7e57c2', density: 0.7, opacity: 0.5, mod: { type: 'parent' } });
    edit(2, ring.id, { opacity: 0.25, rings: 1, speed: 0.03 });
    report.stages[0].notes = 'Example: bright white-gold disc with a warm glow and three counter-rotating rings of dots.';
    report.stages[1].notes = 'Example: smaller and more orange, brightness drifts, dots slowly spiral inwards.';
    report.stages[2].notes = 'Example: dim red-violet oval that fades out and returns; a few slow dots remain.';
    return report;
  };
})(window.KT);
