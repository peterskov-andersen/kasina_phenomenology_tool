'use strict';
// Morphing between stages. Layers with the same id (i.e. the same object
// copied from one stage to the next) are interpolated parameter by parameter;
// numbers are blended linearly, colours in OKLab. Layers that exist in only
// one stage fade out or in.
(function (KT) {
  function lerp(a, b, m) {
    if (typeof a === 'number' && typeof b === 'number') return a + (b - a) * m;
    if (typeof a === 'string' && typeof b === 'string' && KT.color.HEX_RE.test(a) && KT.color.HEX_RE.test(b)) {
      return KT.color.mixHex(a, b, m);
    }
    if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a)) {
      const out = {};
      for (const k of Object.keys(b)) out[k] = k in a ? lerp(a[k], b[k], m) : b[k];
      return out;
    }
    return m < 0.5 ? a : b;   // discrete settings switch half-way
  }

  const effOpacity = (l) => (l.visible ? l.opacity : 0);

  KT.interpolateScenes = function (A, B, m) {
    const out = { background: lerp(A.background, B.background, m), layers: [] };
    const aById = new Map(A.layers.map((l) => [l.id, l]));
    const bIds = new Set(B.layers.map((l) => l.id));
    for (const la of A.layers) {
      if (!bIds.has(la.id)) out.layers.push({ ...la, visible: true, opacity: effOpacity(la) * (1 - m) });
    }
    for (const lb of B.layers) {
      const la = aById.get(lb.id);
      if (la && la.type === lb.type) {
        const l = lerp(la, lb, m);
        l.visible = true;
        l.opacity = effOpacity(la) + (effOpacity(lb) - effOpacity(la)) * m;
        out.layers.push(l);
      } else {
        out.layers.push({ ...lb, visible: true, opacity: effOpacity(lb) * m });
      }
    }
    return out;
  };

  // Which scene to show at time u (s) into a beginning → midway → tail sequence.
  KT.sequenceFrame = function (report, u) {
    const { hold, morph } = report.sequence;
    const S = report.stages;
    const ease = (x) => 0.5 - 0.5 * Math.cos(Math.PI * x);
    for (let i = 0; i < S.length; i++) {
      if (u < hold) return { scene: S[i].scene, label: S[i].label, done: false };
      u -= hold;
      if (i < S.length - 1 && morph > 0) {
        if (u < morph) {
          return { scene: KT.interpolateScenes(S[i].scene, S[i + 1].scene, ease(u / morph)), label: S[i].label + ' → ' + S[i + 1].label, done: false };
        }
        u -= morph;
      }
    }
    return { scene: S[S.length - 1].scene, label: S[S.length - 1].label, done: true };
  };
})(window.KT);
