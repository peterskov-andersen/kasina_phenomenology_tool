'use strict';
// Control panel. Parameter controls are generated from the SCHEMAS below, so a
// new parameter only needs a schema line (plus its use in the renderer).
(function (KT) {
  const SWATCHES = ['#ffffff', '#fff4d6', '#ffe9b0', '#ffd27a', '#ffb347', '#ff8c3a', '#ff7a1a',
    '#ff3b1f', '#c2185b', '#7e57c2', '#3f51b5', '#00acc1', '#26a69a', '#9ccc65', '#000000'];

  const BLEND = [['normal', 'Normal'], ['additive', 'Additive (light)']];
  const MOD_TYPES = [['steady', 'Steady'], ['flicker', 'Flicker (periodic)'],
    ['fadeCycle', 'Fade out and return'], ['drift', 'Irregular drift'], ['parent', 'Follow parent disc']];

  const is = (...types) => (l) => types.includes(l.mod.type);
  const free = (l) => !l.attachTo;

  const MOD_FIELDS = [
    { section: 'Stability' },
    { k: 'mod.type', label: 'Type', type: 'select', options: MOD_TYPES, rebuild: true },
    { note: 'Flicker at roughly 3–30 Hz can trigger seizures in people with photosensitive epilepsy. Screen participants before use.', when: is('flicker') },
    { k: 'mod.freq', label: 'Frequency (Hz)', type: 'range', min: 0.1, max: 40, step: 0.1, when: is('flicker') },
    { k: 'mod.waveform', label: 'Waveform', type: 'select', rebuild: true, when: is('flicker'),
      options: [['square', 'Square (on/off)'], ['sine', 'Sine'], ['triangle', 'Triangle']] },
    { k: 'mod.duty', label: 'Duty cycle', type: 'range', min: 0.05, max: 0.95, step: 0.01, when: (l) => l.mod.type === 'flicker' && l.mod.waveform === 'square' },
    { k: 'mod.holdOn', label: 'Hold visible (s)', type: 'range', min: 0, max: 20, step: 0.1, when: is('fadeCycle') },
    { k: 'mod.fadeOut', label: 'Fade out (s)', type: 'range', min: 0, max: 20, step: 0.1, when: is('fadeCycle') },
    { k: 'mod.holdOff', label: 'Gone (s)', type: 'range', min: 0, max: 20, step: 0.1, when: is('fadeCycle') },
    { k: 'mod.fadeIn', label: 'Fade in (s)', type: 'range', min: 0, max: 20, step: 0.1, when: is('fadeCycle') },
    { k: 'mod.rate', label: 'Drift rate (/s)', type: 'range', min: 0.02, max: 5, step: 0.01, when: is('drift') },
    { k: 'mod.seed', label: 'Random seed', type: 'range', min: 0, max: 999, step: 1, when: is('drift') },
    { k: 'mod.depth', label: 'Depth', type: 'range', min: 0, max: 1, step: 0.01, when: is('flicker', 'fadeCycle', 'drift') },
    { k: 'mod.phase', label: 'Phase (cycles)', type: 'range', min: 0, max: 1, step: 0.01, when: is('flicker', 'fadeCycle') },
  ];

  const attachOptions = (scene, layer) => [['', '(none: free position)']].concat(
    scene.layers.filter((l) => l.type === 'disc' && l.id !== layer.id).map((l) => [l.id, l.name]));

  const SCHEMAS = {
    disc: [
      { section: 'Shape' },
      { k: 'x', label: 'Position x', type: 'range', min: -1.5, max: 1.5, step: 0.005 },
      { k: 'y', label: 'Position y', type: 'range', min: -1, max: 1, step: 0.005 },
      { k: 'rx', label: 'Radius x', type: 'range', min: 0.005, max: 1.5, step: 0.005 },
      { k: 'ry', label: 'Radius y', type: 'range', min: 0.005, max: 1.5, step: 0.005 },
      { k: 'rot', label: 'Rotation (°)', type: 'range', min: -90, max: 90, step: 1 },
      { k: 'softness', label: 'Edge softness', type: 'range', min: 0.001, max: 1, step: 0.001 },
      { section: 'Colour' },
      { k: 'colorInner', label: 'Centre colour', type: 'color' },
      { k: 'colorOuter', label: 'Edge colour', type: 'color' },
      { k: 'gradient', label: 'Centre → edge', type: 'range', min: 0.1, max: 6, step: 0.05 },
      { k: 'opacity', label: 'Opacity', type: 'range', min: 0, max: 1, step: 0.01 },
      { k: 'blend', label: 'Blend', type: 'select', options: BLEND },
      ...MOD_FIELDS,
    ],
    aura: [
      { section: 'Placement' },
      { k: 'attachTo', label: 'Around disc', type: 'select', options: attachOptions, rebuild: true },
      { k: 'x', label: 'Position x', type: 'range', min: -1.5, max: 1.5, step: 0.005, when: free },
      { k: 'y', label: 'Position y', type: 'range', min: -1, max: 1, step: 0.005, when: free },
      { k: 'rx', label: 'Radius x', type: 'range', min: 0.005, max: 1.5, step: 0.005, when: free },
      { k: 'ry', label: 'Radius y', type: 'range', min: 0.005, max: 1.5, step: 0.005, when: free },
      { k: 'rot', label: 'Rotation (°)', type: 'range', min: -90, max: 90, step: 1, when: free },
      { k: 'size', label: 'Size (× radius)', type: 'range', min: 1, max: 6, step: 0.01 },
      { section: 'Cloud' },
      { k: 'color', label: 'Colour', type: 'color' },
      { k: 'opacity', label: 'Opacity', type: 'range', min: 0, max: 1, step: 0.01 },
      { k: 'density', label: 'Density', type: 'range', min: 0, max: 4, step: 0.01 },
      { k: 'falloff', label: 'Falloff', type: 'range', min: 0.2, max: 6, step: 0.05 },
      { k: 'turbulence', label: 'Cloudiness', type: 'range', min: 0, max: 1, step: 0.01 },
      { k: 'noiseScale', label: 'Cloud grain', type: 'range', min: 0.5, max: 20, step: 0.1 },
      { k: 'drift', label: 'Cloud motion', type: 'range', min: 0, max: 1, step: 0.005 },
      { k: 'blend', label: 'Blend', type: 'select', options: BLEND },
      ...MOD_FIELDS,
    ],
    dotRing: [
      { section: 'Orbit' },
      { k: 'attachTo', label: 'Around disc', type: 'select', options: attachOptions, rebuild: true },
      { k: 'x', label: 'Centre x', type: 'range', min: -1.5, max: 1.5, step: 0.005, when: free },
      { k: 'y', label: 'Centre y', type: 'range', min: -1, max: 1, step: 0.005, when: free },
      { k: 'radius', label: 'Inner radius', type: 'range', min: 0.02, max: 1.5, step: 0.005 },
      { k: 'ellipticity', label: 'Ellipticity', type: 'range', min: 0.05, max: 1, step: 0.01 },
      { k: 'rot', label: 'Orbit tilt (°)', type: 'range', min: -90, max: 90, step: 1 },
      { k: 'speed', label: 'Speed (rev/s)', type: 'range', min: -2, max: 2, step: 0.005 },
      { k: 'wobble', label: 'Wobble', type: 'range', min: 0, max: 0.5, step: 0.005 },
      { section: 'Multiple rings and spiral' },
      { k: 'rings', label: 'Number of rings', type: 'range', min: 1, max: 24, step: 1 },
      { k: 'ringSpacing', label: 'Ring spacing', type: 'range', min: 0.01, max: 0.6, step: 0.005 },
      { k: 'countStep', label: 'Extra dots/ring', type: 'range', min: -10, max: 30, step: 1 },
      { k: 'direction', label: 'Directions', type: 'select', options: [['same', 'All rings same way'], ['alternate', 'Neighbours counter-rotate']] },
      { k: 'speedFalloff', label: 'Outer slower', type: 'range', min: 0, max: 2, step: 0.01 },
      { k: 'twist', label: 'Spiral twist (°/unit)', type: 'range', min: -720, max: 720, step: 1 },
      { k: 'radialSpeed', label: 'Spiral flow (/s)', type: 'range', min: -0.5, max: 0.5, step: 0.005 },
      { note: 'Spiral flow moves the rings outward (+) or inward (−) while they rotate, so each dot traces a spiral. Twist bends rings into spiral arms.', hint: true },
      { section: 'Dots' },
      { k: 'count', label: 'Dots (inner ring)', type: 'range', min: 1, max: 120, step: 1 },
      { k: 'dotSize', label: 'Dot size', type: 'range', min: 0.002, max: 0.1, step: 0.001 },
      { k: 'softness', label: 'Dot softness', type: 'range', min: 0.02, max: 1, step: 0.01 },
      { k: 'color', label: 'Colour', type: 'color' },
      { k: 'opacity', label: 'Opacity', type: 'range', min: 0, max: 1, step: 0.01 },
      { k: 'blend', label: 'Blend', type: 'select', options: BLEND },
      ...MOD_FIELDS,
    ],
  };

  const TYPE_LABEL = { disc: 'Disc', aura: 'Aura', dotRing: 'Dot rings' };

  // ---- small DOM helpers ----
  function el(tag, attrs = {}, ...children) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') e.className = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v);
    }
    for (const c of children) e.append(c);
    return e;
  }
  const getPath = (o, path) => path.split('.').reduce((a, k) => a[k], o);
  function setPath(o, path, v) {
    const keys = path.split('.'); const last = keys.pop();
    keys.reduce((a, k) => a[k], o)[last] = v;
  }
  const decimals = (step) => (String(step).split('.')[1] || '').length;

  // Slider + exact number field. Returns the row; row.setValue(v) updates it silently.
  function rangeControl(label, value, def, onValue) {
    const range = el('input', { type: 'range', min: def.min, max: def.max, step: def.step });
    const num = el('input', { type: 'number', min: def.min, max: def.max, step: def.step, class: 'num' });
    const show = (v) => { range.value = v; num.value = (+v).toFixed(decimals(def.step)); };
    show(value);
    range.addEventListener('input', () => { num.value = (+range.value).toFixed(decimals(def.step)); onValue(parseFloat(range.value)); });
    num.addEventListener('change', () => { const v = parseFloat(num.value); if (!isNaN(v)) { range.value = v; onValue(v); } });
    const row = el('div', { class: 'row' }, el('label', { title: label }, label), range, num);
    row.setValue = show;
    return row;
  }

  // Colour: picker, hex field, swatches, and optional perceptual OKLCH sliders.
  let oklchOpen = false;
  function colorControl(label, value, onValue) {
    const picker = el('input', { type: 'color' });
    const hex = el('input', { type: 'text', class: 'hex', maxlength: 7 });
    let lch = KT.color.hexToOklch(value);
    const gamut = el('span', { class: 'sub gamut' });

    const sliders = {
      l: rangeControl('Lightness', lch.l, { min: 0, max: 1, step: 0.005 }, (v) => fromSliders('l', v)),
      c: rangeControl('Chroma', lch.c, { min: 0, max: 0.37, step: 0.001 }, (v) => fromSliders('c', v)),
      h: rangeControl('Hue (°)', lch.h, { min: 0, max: 360, step: 1 }, (v) => fromSliders('h', v)),
    };

    function show(v) { picker.value = v; hex.value = v; }
    function fromHex(v) {
      show(v);
      const next = KT.color.hexToOklch(v);
      if (next.c < 1e-3) next.h = lch.h;            // greys have no hue: keep the previous one
      lch = next;
      for (const k of ['l', 'c', 'h']) sliders[k].setValue(lch[k]);
      gamut.textContent = '';
      onValue(v);
    }
    function fromSliders(key, v) {
      lch[key] = v;
      const res = KT.color.oklchToHex(lch);
      show(res.hex);
      gamut.textContent = res.clipped ? 'Outside screen gamut: chroma reduced' : '';
      onValue(res.hex);
    }

    show(value);
    picker.addEventListener('input', () => fromHex(picker.value));
    hex.addEventListener('change', () => { if (KT.color.HEX_RE.test(hex.value)) fromHex(hex.value.toLowerCase()); });
    const swatches = el('div', { class: 'swatches' }, ...SWATCHES.map((c) => {
      const s = el('button', { class: 'swatch', title: c, onclick: () => fromHex(c) });
      s.style.background = c; return s;
    }));
    const details = el('details', { class: 'oklch' }, el('summary', {}, 'Perceptual sliders (OKLCH)'),
      sliders.l, sliders.c, sliders.h, gamut);
    details.open = oklchOpen;
    details.addEventListener('toggle', () => { oklchOpen = details.open; });
    return el('div', { class: 'row color' }, el('label', {}, label), picker, hex, swatches, details);
  }

  function selectControl(label, value, options, onValue) {
    const sel = el('select', {}, ...options.map(([v, text]) => {
      const o = el('option', { value: v }, text); if (v === value) o.selected = true; return o;
    }));
    sel.addEventListener('change', () => onValue(sel.value));
    return el('div', { class: 'row' }, el('label', {}, label), sel);
  }

  function textControl(label, value, onValue, type = 'text') {
    const input = el('input', { type, class: 'name' });
    input.value = value || '';
    input.addEventListener('input', () => onValue(input.value));
    return el('div', { class: 'row' }, el('label', {}, label), input);
  }

  class UI {
    constructor(app) {
      this.app = app;
      this.selectedId = null;
      this.root = {
        report: document.getElementById('report'), global: document.getElementById('global'),
        layers: document.getElementById('layers'), params: document.getElementById('params'),
      };
    }

    get scene() { return this.app.scene; }

    renderAll() {
      if (!KT.findLayer(this.scene, this.selectedId)) this.selectedId = this.scene.layers.length ? this.scene.layers[this.scene.layers.length - 1].id : null;
      this.renderReport(); this.renderGlobal(); this.renderLayers(); this.renderParams();
    }

    renderReport() {
      const r = this.root.report; r.innerHTML = '';
      const app = this.app, report = app.report, meta = report.meta;
      const stage = report.stages[app.stageIndex];
      const tabs = el('div', { class: 'tabs' }, ...report.stages.map((st, i) =>
        el('button', { class: i === app.stageIndex ? 'active' : '', title: 'Key ' + (i + 1), onclick: () => app.setStage(i) },
          (i + 1) + '. ' + st.label)));
      const notes = el('textarea', { rows: 3, placeholder: 'Describe this stage in your own words…' });
      notes.value = stage.notes;
      notes.addEventListener('input', () => { stage.notes = notes.value; app.changed(); });

      const seqBtn = el('button', { id: 'seqBtn', onclick: () => app.toggleSequence() }, app.sequence.playing ? 'Stop sequence' : '▶ Play 1 → 2 → 3');
      r.append(
        el('h2', {}, 'Report'),
        textControl('Participant ID', meta.participant, (v) => { meta.participant = v; app.changed(); }),
        textControl('Session / sit', meta.session, (v) => { meta.session = v; app.changed(); }),
        textControl('Date', meta.date, (v) => { meta.date = v; app.changed(); }, 'date'),
        el('h3', {}, 'Stage'),
        tabs,
        notes,
        el('div', { class: 'row buttons' },
          el('button', { onclick: () => app.copyPreviousStage() }, 'Copy previous stage here'),
          el('button', { onclick: () => app.loadExampleReport() }, 'Load 3-stage example')),
        el('h3', {}, 'Sequence playback'),
        rangeControl('Hold each (s)', report.sequence.hold, { min: 0, max: 30, step: 0.5 }, (v) => { report.sequence.hold = v; app.changed(); }),
        rangeControl('Morph (s)', report.sequence.morph, { min: 0, max: 30, step: 0.5 }, (v) => { report.sequence.morph = v; app.changed(); }),
        el('div', { class: 'row buttons' }, seqBtn),
      );
      if (app.stageIndex === 0) r.querySelector('.row.buttons button').disabled = true;   // nothing before stage 1
    }

    renderGlobal() {
      const r = this.root.global; r.innerHTML = '';
      const app = this.app;
      const presetSel = el('select', {}, ...Object.keys(KT.PRESETS).map((n) => el('option', { value: n }, n)));
      r.append(
        el('h2', {}, 'Scene for this stage'),
        el('div', { class: 'row buttons' }, presetSel,
          el('button', { onclick: () => app.setScene(KT.PRESETS[presetSel.value]()) }, 'Load preset')),
        el('h3', {}, 'Background'),
        rangeControl('Brightness', this.scene.background.level, { min: 0, max: 0.6, step: 0.005 }, (v) => { this.scene.background.level = v; app.changed(); }),
        colorControl('Tint', this.scene.background.tint, (v) => { this.scene.background.tint = v; app.changed(); }),
        el('h3', {}, 'View and files'),
        el('div', { class: 'row buttons' },
          el('button', { id: 'playBtn', onclick: () => app.togglePlay() }, app.playing ? 'Pause' : 'Play'),
          el('button', { onclick: () => app.resetClock() }, 'Reset clock'),
          el('button', { onclick: () => app.toggleFullscreen() }, 'Fullscreen')),
        el('div', { class: 'row buttons' },
          el('button', { onclick: () => app.exportReport() }, 'Export report (JSON)'),
          el('button', { onclick: () => app.importReport() }, 'Import JSON'),
          el('button', { onclick: () => app.savePng() }, 'Save PNG'),
          el('button', { onclick: () => app.newReport() }, 'New report')),
      );
    }

    renderLayers() {
      const r = this.root.layers; r.innerHTML = '';
      const app = this.app, scene = this.scene;
      r.append(el('h2', {}, 'Layers ', el('span', { class: 'sub' }, '(top = front)')),
        el('div', { class: 'row buttons' }, ...KT.LAYER_TYPES.map((t) =>
          el('button', { onclick: () => this.addLayer(t) }, '+ ' + TYPE_LABEL[t]))));
      const list = el('ul', { class: 'layer-list' });
      [...scene.layers].reverse().forEach((layer) => {
        const idx = scene.layers.indexOf(layer);
        const vis = el('input', { type: 'checkbox', title: 'Visible' });
        vis.checked = layer.visible;
        vis.addEventListener('click', (e) => e.stopPropagation());
        vis.addEventListener('change', () => { layer.visible = vis.checked; app.changed(); });
        const btn = (txt, title, fn) => el('button', { class: 'icon', title, onclick: (e) => { e.stopPropagation(); fn(); } }, txt);
        const li = el('li', { class: layer.id === this.selectedId ? 'selected' : '', onclick: () => { this.selectedId = layer.id; this.renderLayers(); this.renderParams(); } },
          vis,
          el('span', { class: 'lname' }, layer.name, el('span', { class: 'ltype' }, ' ' + TYPE_LABEL[layer.type])),
          btn('▲', 'Move forward', () => this.move(idx, +1)),
          btn('▼', 'Move back', () => this.move(idx, -1)),
          btn('⧉', 'Duplicate', () => this.duplicate(idx)),
          btn('✕', 'Delete', () => this.remove(idx)));
        list.append(li);
      });
      r.append(list);
    }

    renderParams() {
      const r = this.root.params; r.innerHTML = '';
      const layer = KT.findLayer(this.scene, this.selectedId);
      if (!layer) { r.append(el('p', { class: 'sub' }, 'Add a layer to begin.')); return; }
      const app = this.app;
      r.append(el('h2', {}, TYPE_LABEL[layer.type] + ' settings'),
        textControl('Name', layer.name, (v) => { layer.name = v; app.changed(); this.renderLayers(); }));

      for (const def of SCHEMAS[layer.type]) {
        if (def.when && !def.when(layer)) continue;
        if (def.section) { r.append(el('h3', {}, def.section)); continue; }
        if (def.note) { r.append(el('p', { class: def.hint ? 'hint' : 'warn' }, def.note)); continue; }
        const onValue = (v) => {
          setPath(layer, def.k, v); app.changed();
          if (def.rebuild) { this.renderParams(); this.renderLayers(); }
        };
        const value = getPath(layer, def.k);
        if (def.type === 'range') r.append(rangeControl(def.label, value, def, onValue));
        else if (def.type === 'color') r.append(colorControl(def.label, value, onValue));
        else if (def.type === 'select') {
          const opts = typeof def.options === 'function' ? def.options(this.scene, layer) : def.options;
          r.append(selectControl(def.label, value, opts, onValue));
        }
      }
    }

    addLayer(type) {
      const overrides = {};
      const disc = [...this.scene.layers].reverse().find((l) => l.type === 'disc');
      if (type !== 'disc' && disc) overrides.attachTo = disc.id;
      const layer = KT.createLayer(type, overrides);
      if (type === 'aura') this.scene.layers.unshift(layer);   // auras default to behind everything
      else this.scene.layers.push(layer);
      this.selectedId = layer.id; this.app.changed(); this.renderLayers(); this.renderParams();
    }

    move(idx, dir) {
      const j = idx + dir, L = this.scene.layers;
      if (j < 0 || j >= L.length) return;
      [L[idx], L[j]] = [L[j], L[idx]];
      this.app.changed(); this.renderLayers();
    }

    duplicate(idx) {
      const copy = KT.cloneLayer(this.scene.layers[idx]);
      this.scene.layers.splice(idx + 1, 0, copy);
      this.selectedId = copy.id; this.app.changed(); this.renderLayers(); this.renderParams();
    }

    remove(idx) {
      const [gone] = this.scene.layers.splice(idx, 1);
      for (const l of this.scene.layers) {
        if (l.attachTo === gone.id) {          // keep dependants where they are, but detach them
          Object.assign(l, { x: gone.x, y: gone.y, rx: gone.rx ?? l.rx, ry: gone.ry ?? l.ry, attachTo: '' });
          if (l.mod.type === 'parent') l.mod.type = 'steady';
        }
      }
      this.app.changed(); this.renderAll();
    }
  }

  KT.UI = UI;
})(window.KT);
