'use strict';
// Temporal stability of a layer. Returns a gain in [0, 1] that multiplies the
// layer's opacity at time t (seconds).
(function (KT) {
  const TAU = Math.PI * 2;
  const frac = (x) => x - Math.floor(x);
  const clamp01 = (x) => Math.min(1, Math.max(0, x));

  function hash1(n) { return frac(Math.sin(n * 127.1 + 311.7) * 43758.5453); }
  function smoothNoise1(x, seed) {
    const i = Math.floor(x), f = x - i, u = f * f * (3 - 2 * f), s = seed * 17.13;
    return hash1(i + s) * (1 - u) + hash1(i + 1 + s) * u;
  }

  // Raw waveform in [0, 1]; 1 = fully present.
  function wave(mod, t) {
    switch (mod.type) {
      case 'flicker': {
        const ph = frac(t * mod.freq + mod.phase);
        if (mod.waveform === 'sine') return 0.5 + 0.5 * Math.cos(TAU * ph);
        if (mod.waveform === 'triangle') return Math.abs(1 - 2 * ph);
        return ph < mod.duty ? 1 : 0;
      }
      case 'fadeCycle': {
        const T = mod.holdOn + mod.fadeOut + mod.holdOff + mod.fadeIn;
        if (T <= 0) return 1;
        let u = frac(t / T + mod.phase) * T;
        if (u < mod.holdOn) return 1; u -= mod.holdOn;
        if (u < mod.fadeOut) return 0.5 + 0.5 * Math.cos(Math.PI * u / mod.fadeOut); u -= mod.fadeOut;
        if (u < mod.holdOff) return 0; u -= mod.holdOff;
        return 0.5 - 0.5 * Math.cos(Math.PI * u / Math.max(mod.fadeIn, 1e-6));
      }
      case 'drift': {
        const x = t * mod.rate;
        const n = 0.65 * smoothNoise1(x, mod.seed) + 0.35 * smoothNoise1(x * 2.3 + 5, mod.seed + 1);
        return clamp01((n - 0.15) / 0.7);
      }
      default:
        return 1;
    }
  }

  KT.modulationGain = function (mod, t) {
    if (!mod || mod.type === 'steady' || mod.type === 'parent') return 1;
    return 1 - mod.depth * (1 - wave(mod, t));
  };

  // Gain for a layer, following its parent if its modulation type is 'parent'.
  KT.layerGain = function (scene, layer, t, depth = 0) {
    if (layer.mod.type === 'parent' && layer.attachTo && depth < 4) {
      const parent = KT.findLayer(scene, layer.attachTo);
      if (parent) return KT.layerGain(scene, parent, t, depth + 1);
    }
    return KT.modulationGain(layer.mod, t);
  };
})(window.KT);
