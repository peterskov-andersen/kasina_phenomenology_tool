'use strict';
// Colour utilities: sRGB hex <-> OKLab / OKLCH (Björn Ottosson, 2020).
// OKLCH is a perceptual colour space: L = lightness, C = chroma (colourfulness),
// H = hue angle. Equal slider steps look like roughly equal visual changes, and
// changing one of L/C/H leaves the other two perceptually unchanged.
window.KT = window.KT || {};
(function (KT) {
  const HEX_RE = /^#[0-9a-fA-F]{6}$/;

  function hexToRgb(hex) {
    const n = parseInt((HEX_RE.test(hex) ? hex : '#000000').slice(1), 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }
  function rgbToHex(rgb) {
    return '#' + rgb.map((c) => Math.round(Math.min(1, Math.max(0, c)) * 255).toString(16).padStart(2, '0')).join('');
  }
  const toLinear = (c) => (c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4));
  const toGamma = (c) => (c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055);

  function linToOklab([r, g, b]) {
    const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
    const m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
    const s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
    return [
      0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
      1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
      0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s,
    ];
  }
  function oklabToLin([L, a, b]) {
    const l = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3;
    const m = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3;
    const s = (L - 0.0894841775 * a - 1.2914855480 * b) ** 3;
    return [
      4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
      -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
      -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s,
    ];
  }

  const hexToOklab = (hex) => linToOklab(hexToRgb(hex).map(toLinear));
  const inGamut = (lin) => lin.every((c) => c >= -1e-4 && c <= 1 + 1e-4);

  function hexToOklch(hex) {
    const [L, a, b] = hexToOklab(hex);
    const c = Math.hypot(a, b);
    let h = (Math.atan2(b, a) * 180) / Math.PI;
    if (h < 0) h += 360;
    return { l: L, c, h };
  }

  // OKLCH -> hex. Colours outside the sRGB screen gamut keep their lightness
  // and hue, and chroma is reduced until they fit.
  function oklchToHex({ l, c, h }) {
    const hr = (h * Math.PI) / 180;
    const lab = (cc) => [l, cc * Math.cos(hr), cc * Math.sin(hr)];
    let lin = oklabToLin(lab(c));
    let clipped = false;
    if (!inGamut(lin)) {
      clipped = true;
      let lo = 0, hi = c;
      for (let i = 0; i < 24; i++) {
        const mid = (lo + hi) / 2;
        if (inGamut(oklabToLin(lab(mid)))) lo = mid; else hi = mid;
      }
      lin = oklabToLin(lab(lo));
    }
    return { hex: rgbToHex(lin.map((v) => toGamma(Math.min(1, Math.max(0, v))))), clipped };
  }

  // Perceptually even blend between two colours (used when morphing stages).
  function mixHex(a, b, m) {
    const A = hexToOklab(a), B = hexToOklab(b);
    const lin = oklabToLin(A.map((v, i) => v + (B[i] - v) * m));
    return rgbToHex(lin.map((v) => toGamma(Math.min(1, Math.max(0, v)))));
  }

  KT.color = { HEX_RE, hexToRgb, rgbToHex, hexToOklch, oklchToHex, mixHex };
})(window.KT);
