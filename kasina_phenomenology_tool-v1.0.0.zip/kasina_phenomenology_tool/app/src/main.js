'use strict';
// App bootstrap: owns the report, the current stage, the clock, the render
// loop, sequence playback, persistence and keyboard shortcuts.
(function (KT) {
  const STORAGE_KEY = 'kasina-tool-report-v2';
  const LEGACY_KEY = 'kasina-tool-scene-v1';
  const canvas = document.getElementById('view');
  const status = document.getElementById('status');
  document.getElementById('version').textContent = 'v' + KT.VERSION;

  let renderer;
  try { renderer = new KT.Renderer(canvas); } catch (err) {
    document.body.classList.add('error');
    status.textContent = 'Could not start renderer: ' + err.message;
    console.error(err);
    return;
  }

  function loadSaved() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_KEY);
      if (raw) return KT.normalizeReport(JSON.parse(raw));
    } catch (e) { /* storage unavailable or corrupt: start fresh */ }
    return KT.createReport(KT.PRESETS[KT.DEFAULT_PRESET]());
  }

  let saveTimer = null;
  const frameDts = [];

  const app = {
    report: loadSaved(),
    stageIndex: 0,
    playing: true,
    clock: 0,                                  // seconds of stimulus time (stops while paused)
    refreshHz: 60,
    sequence: { playing: false, t: 0 },

    get scene() { return app.report.stages[app.stageIndex].scene; },

    changed() {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(app.report)); } catch (e) { /* ignore */ }
      }, 300);
    },
    setScene(scene) {
      app.report.stages[app.stageIndex].scene = KT.normalizeScene(scene);
      app.changed(); ui.renderAll();
    },
    setReport(report) {
      app.report = KT.normalizeReport(report);
      app.stageIndex = 0; app.stopSequence(); app.changed(); ui.renderAll();
    },
    setStage(i) {
      app.stopSequence();
      app.stageIndex = i; ui.renderAll();
    },
    copyPreviousStage() {
      if (app.stageIndex === 0) return;
      const prev = app.report.stages[app.stageIndex - 1];
      if (app.scene.layers.length && !confirm(`Replace this stage's scene with a copy of "${prev.label}"?`)) return;
      app.report.stages[app.stageIndex].scene = KT.cloneScene(prev.scene);
      app.changed(); ui.renderAll();
    },
    loadExampleReport() {
      if (!confirm('Replace all three stages with the example report?')) return;
      app.setReport(KT.exampleReport());
    },
    newReport() {
      if (!confirm('Start a new, empty report? Export the current one first if you want to keep it.')) return;
      app.setReport(KT.createReport(KT.PRESETS[KT.DEFAULT_PRESET]()));
    },

    toggleSequence() { app.sequence.playing ? app.stopSequence() : app.startSequence(); },
    startSequence() {
      app.sequence = { playing: true, t: 0 };
      if (!app.playing) app.togglePlay();
      ui.renderReport();
    },
    stopSequence() {
      if (!app.sequence.playing) return;
      app.sequence.playing = false;
      ui.renderReport();
    },

    togglePlay() {
      app.playing = !app.playing;
      const b = document.getElementById('playBtn'); if (b) b.textContent = app.playing ? 'Pause' : 'Play';
    },
    resetClock() { app.clock = 0; },
    toggleFullscreen() {
      if (document.fullscreenElement) document.exitFullscreen();
      else document.documentElement.requestFullscreen().catch(() => {});
    },
    exportReport() {
      const blob = new Blob([KT.serializeReport(app.report)], { type: 'application/json' });
      const who = (app.report.meta.participant || 'report').replace(/[^\w-]+/g, '_');
      download(blob, `kasina_${who}_${stamp()}.json`);
    },
    importReport() {
      const input = document.createElement('input');
      input.type = 'file'; input.accept = '.json,application/json';
      input.onchange = async () => {
        try { app.setReport(JSON.parse(await input.files[0].text())); }
        catch (e) { alert('Could not read that file: ' + e.message); }
      };
      input.click();
    },
    savePng() {
      const key = app.report.stages[app.stageIndex].key;
      canvas.toBlob((b) => download(b, `kasina_${key}_${stamp()}.png`));
    },
  };

  function stamp() { return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19); }
  function download(blob, name) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  const ui = new KT.UI(app);
  ui.renderAll();

  // ---- render loop ----
  let last = performance.now();
  function frame(now) {
    const dt = (now - last) / 1000; last = now;
    if (app.playing) app.clock += dt;

    frameDts.push(dt); if (frameDts.length > 120) frameDts.shift();
    const sorted = [...frameDts].sort((a, b) => a - b);
    app.refreshHz = 1 / Math.max(sorted[sorted.length >> 1], 1e-3);

    let scene = app.scene;
    let label = app.report.stages[app.stageIndex].label;
    if (app.sequence.playing) {
      if (app.playing) app.sequence.t += dt;
      const f = KT.sequenceFrame(app.report, app.sequence.t);
      scene = f.scene; label = 'Sequence: ' + f.label;
      if (f.done) { app.stopSequence(); app.setStage(app.report.stages.length - 1); }
    }
    renderer.render(scene, app.clock);

    const maxFlicker = Math.max(0, ...scene.layers.filter((l) => l.visible && l.mod.type === 'flicker').map((l) => l.mod.freq));
    const warn = maxFlicker > app.refreshHz / 2 ? `  ⚠ ${maxFlicker.toFixed(1)} Hz flicker exceeds half the refresh rate` : '';
    status.textContent = `${label} · ${Math.round(app.refreshHz)} Hz display · t = ${app.clock.toFixed(1)} s${app.playing ? '' : ' (paused)'}${warn}`;
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // ---- keyboard shortcuts (ignored while typing in a field) ----
  window.addEventListener('keydown', (e) => {
    if (['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;
    const k = e.key.toLowerCase();
    if (k === 'h') document.body.classList.toggle('panel-hidden');
    else if (k === 'f') app.toggleFullscreen();
    else if (k === 's') app.toggleSequence();
    else if (k === ' ') { e.preventDefault(); app.togglePlay(); }
    else if (['1', '2', '3'].includes(k)) app.setStage(+k - 1);
  });

  KT.app = app;   // handy for debugging in the browser console
})(window.KT);
