'use strict';
// Data model.
//
// A REPORT is what one practitioner saves: metadata plus three STAGES
// (beginning / midway / tail end), each holding a SCENE. A scene is a plain,
// JSON-serialisable object, and everything drawn is a pure function of
// (scene, time), so a saved report is a complete, reproducible description.
//
// Scene coordinates: screen centre is (0, 0); 1 unit = half of the shorter
// screen side. +x is right, +y is up. Rotations are in degrees.
window.KT = window.KT || {};
(function (KT) {
  KT.VERSION = '1.0.0';
  KT.SCHEMA_VERSION = 2;

  const rid = (prefix) => prefix + '-' + Math.random().toString(36).slice(2, 8);
  const deepCopy = (o) => JSON.parse(JSON.stringify(o));

  // Temporal stability ("modulation") applied to a layer's opacity.
  KT.defaultModulation = () => ({
    type: 'steady',        // steady | flicker | fadeCycle | drift | parent
    freq: 2,               // flicker: Hz
    waveform: 'square',    // flicker: square | sine | triangle
    duty: 0.5,             // flicker/square: fraction of the cycle that is "on"
    depth: 1,              // 0 = no effect, 1 = fully off at the trough
    phase: 0,              // cycles (0-1), offsets layers against each other
    holdOn: 2,             // fadeCycle: seconds fully visible
    fadeOut: 1.5,          // fadeCycle: seconds to fade out
    holdOff: 1,            // fadeCycle: seconds gone
    fadeIn: 1.5,           // fadeCycle: seconds to come back
    rate: 0.3,             // drift: approx. changes per second
    seed: Math.floor(Math.random() * 1000), // drift: random seed
  });

  const factories = {
    disc: () => ({
      type: 'disc', name: 'Disc', visible: true,
      x: 0, y: 0, rx: 0.3, ry: 0.3, rot: 0,
      colorInner: '#fff4d6', colorOuter: '#ffb347',
      gradient: 1.5,        // how the centre colour gives way to the edge colour
      softness: 0.03,       // edge blur, in fractions of the radius
      opacity: 1, blend: 'normal',
    }),
    aura: () => ({
      type: 'aura', name: 'Aura', visible: true,
      attachTo: '',         // id of a disc: inherit its centre, radii and rotation
      x: 0, y: 0, rx: 0.3, ry: 0.3, rot: 0,
      size: 1.8,            // outer extent, as a multiple of the (parent) radii
      color: '#ff8c3a', opacity: 0.6,
      density: 1.2,         // overall thickness of the cloud
      falloff: 1.5,         // how quickly it thins towards the edge
      noiseScale: 3,        // size of the cloud structures (higher = finer)
      turbulence: 0.6,      // 0 = smooth glow, 1 = fully cloudy
      drift: 0.08,          // speed at which the cloud texture moves
      blend: 'additive',
    }),
    dotRing: () => ({
      type: 'dotRing', name: 'Dot rings', visible: true,
      attachTo: '',         // id of a disc: orbit around its centre
      x: 0, y: 0,
      radius: 0.5,          // radius of the innermost ring (absolute units)
      ellipticity: 1,       // 1 = circular orbit, <1 = flattened (seen at an angle)
      rot: 0,               // tilt of the orbits, degrees
      count: 12,            // dots on the innermost ring
      dotSize: 0.012, softness: 0.5,
      color: '#ffffff', opacity: 0.9,
      speed: 0.08,          // revolutions per second (negative = clockwise)
      wobble: 0,            // per-dot radial wobble
      rings: 1,             // number of concentric rings
      ringSpacing: 0.12,    // distance between rings
      countStep: 0,         // extra dots on each successive ring
      direction: 'same',    // same | alternate (neighbouring rings counter-rotate)
      speedFalloff: 0,      // 0 = all rings same speed; 1 = speed ∝ 1/radius
      twist: 0,             // spiral twist, degrees per unit of radius
      radialSpeed: 0,       // spiral flow, units/s (+ outward, − inward)
      blend: 'additive',
    }),
  };

  KT.LAYER_TYPES = Object.keys(factories);

  KT.createLayer = function (type, overrides = {}) {
    const layer = Object.assign(factories[type](), { id: rid(type), mod: KT.defaultModulation() });
    const { mod, ...rest } = overrides;
    Object.assign(layer, rest);
    if (mod) Object.assign(layer.mod, mod);
    return layer;
  };

  KT.createScene = (layers = [], background = { level: 0, tint: '#ffffff' }) =>
    ({ background: { ...background }, layers });

  KT.findLayer = (scene, id) => scene.layers.find((l) => l.id === id) || null;

  // Geometry after resolving attachments (aura/dot rings follow a parent disc).
  KT.resolveGeometry = function (scene, layer) {
    const parent = layer.attachTo ? KT.findLayer(scene, layer.attachTo) : null;
    const src = parent || layer;
    return { x: src.x, y: src.y, rx: src.rx, ry: src.ry, rot: src.rot };
  };

  // Fill in missing fields from defaults (imported or older files).
  KT.normalizeScene = function (obj) {
    const scene = KT.createScene();
    if (!obj || typeof obj !== 'object') return scene;
    Object.assign(scene.background, obj.background || {});
    for (const l of obj.layers || []) {
      if (!factories[l.type]) continue;
      const layer = KT.createLayer(l.type, l);
      if (l.id) layer.id = l.id;
      scene.layers.push(layer);
    }
    return scene;
  };

  // Copy keeps layer ids, so the same object can be followed across stages.
  KT.cloneScene = (scene) => deepCopy(scene);

  KT.cloneLayer = function (layer) {
    const copy = deepCopy(layer);
    copy.id = rid(layer.type);
    copy.name = layer.name + ' copy';
    return copy;
  };

  // ---------------- reports (three stages) ----------------
  KT.STAGES = [
    { key: 'beginning', label: 'Beginning (most vivid)' },
    { key: 'midway', label: 'Midway' },
    { key: 'tail', label: 'Tail end' },
  ];

  KT.createReport = function (scene) {
    const base = scene || KT.createScene();
    return {
      schemaVersion: KT.SCHEMA_VERSION,
      meta: { participant: '', session: '', date: new Date().toISOString().slice(0, 10), notes: '' },
      stages: KT.STAGES.map((s) => ({ key: s.key, label: s.label, notes: '', scene: KT.cloneScene(base) })),
      sequence: { hold: 4, morph: 3 },   // playback: seconds per stage, seconds per transition
    };
  };

  // Accepts a v2 report, or a v0.1 single-scene file (copied into all stages).
  KT.normalizeReport = function (obj) {
    if (obj && Array.isArray(obj.stages)) {
      const report = KT.createReport();
      Object.assign(report.meta, obj.meta || {});
      Object.assign(report.sequence, obj.sequence || {});
      report.stages.forEach((st, i) => {
        const src = obj.stages[i];
        if (!src) return;
        st.notes = src.notes || '';
        st.scene = KT.normalizeScene(src.scene);
      });
      return report;
    }
    return KT.createReport(KT.normalizeScene(obj));
  };

  KT.serializeReport = (report) => JSON.stringify({
    app: 'kasina-phenomenology-tool',
    appVersion: KT.VERSION,
    exportedAt: new Date().toISOString(),
    ...report,
  }, null, 2);
})(window.KT);
